const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  login: (email, password) => ipcRenderer.invoke('login', email, password),
  checkWireGuard: () => ipcRenderer.invoke('check-wireguard'),
  installWireGuard: () => ipcRenderer.invoke('install-wireguard'),
  activateKey: (key) => ipcRenderer.invoke('activate-key', key),
  getVpnStatus: () => ipcRenderer.invoke('get-vpn-status'),
  verifyIntegrity: () => ipcRenderer.invoke('verify-integrity'),
  connectVpn: () => ipcRenderer.invoke('connect-vpn'),
  disconnectVpn: () => ipcRenderer.invoke('disconnect-vpn'),
  minimize: () => ipcRenderer.invoke('minimize-window'),
  close: () => ipcRenderer.invoke('close-window'),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
});
