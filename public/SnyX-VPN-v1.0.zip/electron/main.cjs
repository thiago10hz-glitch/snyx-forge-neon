const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const { execSync } = require('child_process');
const fs = require('fs');
const https = require('https');
const crypto = require('crypto');

const SUPABASE_URL = 'https://umhqbgsvfjatcaiwtqnr.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVtaHFiZ3N2ZmphdGNhaXd0cW5yIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwMjYzOTIsImV4cCI6MjA5MTYwMjM5Mn0.CxugRDD3Q9m5trKE34Ppf4utf8MccTm9KBDIWLE87ts';

let mainWindow;
let authToken = null;

// ===== FILE INTEGRITY SYSTEM =====
const INTEGRITY_FILE = path.join(app.getPath('appData'), 'SnyX-VPN', 'integrity.json');
const CONFIG_DIR = path.join(app.getPath('appData'), 'SnyX-VPN');

function hashFile(filePath) {
  try {
    const content = fs.readFileSync(filePath);
    return crypto.createHash('sha256').update(content).digest('hex');
  } catch { return null; }
}

function hashString(str) {
  return crypto.createHash('sha256').update(str).digest('hex');
}

function getAppFileHashes() {
  const files = {};
  const appDir = path.join(__dirname);
  const targets = ['main.cjs', 'preload.cjs', 'index.html'];
  for (const f of targets) {
    const fp = path.join(appDir, f);
    const h = hashFile(fp);
    if (h) files[f] = h;
  }
  // Also hash config if exists
  const configPath = path.join(CONFIG_DIR, 'snyx-vpn.conf');
  const ch = hashFile(configPath);
  if (ch) files['snyx-vpn.conf'] = ch;
  return files;
}

function saveIntegrityBaseline() {
  const hashes = getAppFileHashes();
  if (!fs.existsSync(CONFIG_DIR)) fs.mkdirSync(CONFIG_DIR, { recursive: true });
  // Encrypt the baseline so user can't easily edit it
  const data = JSON.stringify(hashes);
  const key = crypto.createHash('sha256').update('SnyX-VPN-Integrity-Key-2024').digest();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(data, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  fs.writeFileSync(INTEGRITY_FILE, JSON.stringify({ iv: iv.toString('hex'), data: encrypted }));
  return hashes;
}

function loadIntegrityBaseline() {
  try {
    const raw = JSON.parse(fs.readFileSync(INTEGRITY_FILE, 'utf8'));
    const key = crypto.createHash('sha256').update('SnyX-VPN-Integrity-Key-2024').digest();
    const iv = Buffer.from(raw.iv, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
    let decrypted = decipher.update(raw.data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
  } catch { return null; }
}

function verifyIntegrity() {
  const baseline = loadIntegrityBaseline();
  if (!baseline) {
    // First run — save baseline
    saveIntegrityBaseline();
    return { valid: true, first_run: true };
  }
  const current = getAppFileHashes();
  const tampered = [];
  for (const [file, expectedHash] of Object.entries(baseline)) {
    if (file === 'snyx-vpn.conf') continue; // Config changes on connect
    if (current[file] && current[file] !== expectedHash) {
      tampered.push(file);
    }
  }
  if (tampered.length > 0) {
    return { valid: false, tampered, message: `Arquivos modificados detectados: ${tampered.join(', ')}` };
  }
  return { valid: true };
}

// ===== CLEANUP ON EXPIRY =====
function cleanupVpnFiles() {
  try {
    // Disconnect VPN first
    const wgPath = getWireGuardPath();
    if (wgPath) {
      try { execSync(`"${wgPath}" /uninstalltunnelservice snyx-vpn`, { timeout: 15000 }); } catch {}
    }
    // Remove config files
    const configPath = path.join(CONFIG_DIR, 'snyx-vpn.conf');
    if (fs.existsSync(configPath)) fs.unlinkSync(configPath);
    if (fs.existsSync(INTEGRITY_FILE)) fs.unlinkSync(INTEGRITY_FILE);
    return true;
  } catch { return false; }
}

// ===== WINDOW =====
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 500,
    height: 780,
    resizable: false,
    frame: false,
    transparent: false,
    backgroundColor: '#0a0a0a',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, 'preload.cjs')
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

// ===== SUPABASE HELPERS =====
function supabaseFetch(fnPath, body, token) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${SUPABASE_URL}/functions/v1/${fnPath}`);
    const data = JSON.stringify(body);
    const headers = { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON_KEY };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const req = https.request(url, { method: 'POST', headers }, (res) => {
      let chunks = '';
      res.on('data', c => chunks += c);
      res.on('end', () => { try { resolve(JSON.parse(chunks)); } catch { resolve(chunks); } });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function supabaseLogin(email, password) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${SUPABASE_URL}/auth/v1/token?grant_type=password`);
    const data = JSON.stringify({ email, password });
    const req = https.request(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON_KEY } }, (res) => {
      let chunks = '';
      res.on('data', c => chunks += c);
      res.on('end', () => { try { resolve(JSON.parse(chunks)); } catch { resolve({ error: chunks }); } });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// ===== WIREGUARD =====
function isWireGuardInstalled() {
  try {
    return ['C:\\Program Files\\WireGuard\\wireguard.exe', 'C:\\Program Files (x86)\\WireGuard\\wireguard.exe'].some(p => fs.existsSync(p));
  } catch { return false; }
}

function getWireGuardPath() {
  for (const p of ['C:\\Program Files\\WireGuard\\wireguard.exe', 'C:\\Program Files (x86)\\WireGuard\\wireguard.exe']) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function downloadAndInstallWireGuard() {
  return new Promise((resolve, reject) => {
    const installerPath = path.join(app.getPath('temp'), 'wireguard-installer.exe');
    const url = 'https://download.wireguard.com/windows-client/wireguard-installer.exe';
    const file = fs.createWriteStream(installerPath);
    const doDownload = (downloadUrl) => {
      https.get(downloadUrl, (response) => {
        if (response.statusCode === 302 || response.statusCode === 301) {
          return doDownload(response.headers.location);
        }
        response.pipe(file);
        file.on('finish', () => {
          file.close();
          try { execSync(`"${installerPath}" /S`, { timeout: 120000 }); resolve(true); }
          catch (e) { reject(new Error('Falha ao instalar WireGuard: ' + e.message)); }
        });
      }).on('error', reject);
    };
    doDownload(url);
  });
}

// ===== IPC HANDLERS =====
ipcMain.handle('login', async (_, email, password) => {
  try {
    const result = await supabaseLogin(email, password);
    if (result.access_token) { authToken = result.access_token; return { success: true, user: result.user }; }
    return { success: false, error: result.error_description || result.msg || 'Erro no login' };
  } catch (e) { return { success: false, error: e.message }; }
});

ipcMain.handle('check-wireguard', async () => ({ installed: isWireGuardInstalled() }));

ipcMain.handle('install-wireguard', async () => {
  try { await downloadAndInstallWireGuard(); return { success: true }; }
  catch (e) { return { success: false, error: e.message }; }
});

ipcMain.handle('activate-key', async (_, key) => {
  try { return await supabaseFetch('vpn-manage', { action: 'activate', activation_key: key }, authToken); }
  catch (e) { return { error: e.message }; }
});

ipcMain.handle('get-vpn-status', async () => {
  try {
    const status = await supabaseFetch('vpn-manage', { action: 'status' }, authToken);
    
    // If expired, auto-cleanup
    if (status.expired && status.cleanup_required) {
      cleanupVpnFiles();
      return { ...status, cleaned: true };
    }
    
    return status;
  } catch (e) { return { active: false }; }
});

ipcMain.handle('verify-integrity', async () => {
  const result = verifyIntegrity();
  if (!result.valid) {
    // Tampering detected — disconnect VPN and block
    cleanupVpnFiles();
    // Notify server
    try { await supabaseFetch('vpn-manage', { action: 'verify-integrity', file_hashes: getAppFileHashes() }, authToken); } catch {}
  }
  return result;
});

ipcMain.handle('connect-vpn', async () => {
  try {
    // Verify integrity before connecting
    const integrity = verifyIntegrity();
    if (!integrity.valid) {
      return { success: false, error: '🚫 BLOQUEADO: Arquivos do app foram modificados. Reinstale o app.', tampered: true };
    }

    // Check status (also checks expiration)
    const status = await supabaseFetch('vpn-manage', { action: 'status' }, authToken);
    if (status.expired) {
      cleanupVpnFiles();
      return { success: false, error: '⏰ Chave expirada. VPN desativada e arquivos removidos.', expired: true };
    }

    const configResult = await supabaseFetch('vpn-manage', { action: 'get-config' }, authToken);
    if (!configResult.success) return { success: false, error: configResult.error };

    if (!fs.existsSync(CONFIG_DIR)) fs.mkdirSync(CONFIG_DIR, { recursive: true });
    const configPath = path.join(CONFIG_DIR, 'snyx-vpn.conf');
    fs.writeFileSync(configPath, configResult.config);

    // Update integrity baseline with new config
    saveIntegrityBaseline();

    const wgPath = getWireGuardPath();
    if (!wgPath) return { success: false, error: 'WireGuard não encontrado' };

    try { execSync(`"${wgPath}" /installtunnelservice "${configPath}"`, { timeout: 30000 }); }
    catch { return { success: false, error: 'Execute como administrador para conectar a VPN' }; }

    return { success: true, ip: configResult.assigned_ip, server: configResult.server_ip };
  } catch (e) { return { success: false, error: e.message }; }
});

ipcMain.handle('disconnect-vpn', async () => {
  try {
    const wgPath = getWireGuardPath();
    if (wgPath) execSync(`"${wgPath}" /uninstalltunnelservice snyx-vpn`, { timeout: 15000 });
    return { success: true };
  } catch (e) { return { success: false, error: e.message }; }
});

ipcMain.handle('minimize-window', () => mainWindow?.minimize());
ipcMain.handle('close-window', () => app.quit());
ipcMain.handle('open-external', (_, url) => shell.openExternal(url));
