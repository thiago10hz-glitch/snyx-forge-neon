const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const { execSync, exec } = require('child_process');
const fs = require('fs');
const https = require('https');
const http = require('http');

const SUPABASE_URL = 'https://umhqbgsvfjatcaiwtqnr.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVtaHFiZ3N2ZmphdGNhaXd0cW5yIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwMjYzOTIsImV4cCI6MjA5MTYwMjM5Mn0.CxugRDD3Q9m5trKE34Ppf4utf8MccTm9KBDIWLE87ts';

let mainWindow;
let authToken = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 480,
    height: 700,
    resizable: false,
    frame: false,
    transparent: false,
    backgroundColor: '#0a0a0a',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, 'preload.cjs')
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

// Helper: fetch from Supabase
function supabaseFetch(fnPath, body, token) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${SUPABASE_URL}/functions/v1/${fnPath}`);
    const data = JSON.stringify(body);
    const headers = {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_ANON_KEY,
    };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const req = https.request(url, { method: 'POST', headers }, (res) => {
      let chunks = '';
      res.on('data', c => chunks += c);
      res.on('end', () => {
        try { resolve(JSON.parse(chunks)); } catch { resolve(chunks); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// Helper: Supabase auth login
function supabaseLogin(email, password) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${SUPABASE_URL}/auth/v1/token?grant_type=password`);
    const data = JSON.stringify({ email, password });
    const req = https.request(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SUPABASE_ANON_KEY,
      }
    }, (res) => {
      let chunks = '';
      res.on('data', c => chunks += c);
      res.on('end', () => {
        try { resolve(JSON.parse(chunks)); } catch { resolve({ error: chunks }); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// Check if WireGuard is installed (Windows)
function isWireGuardInstalled() {
  try {
    const paths = [
      'C:\\Program Files\\WireGuard\\wireguard.exe',
      'C:\\Program Files (x86)\\WireGuard\\wireguard.exe',
    ];
    return paths.some(p => fs.existsSync(p));
  } catch { return false; }
}

function getWireGuardPath() {
  const paths = [
    'C:\\Program Files\\WireGuard\\wireguard.exe',
    'C:\\Program Files (x86)\\WireGuard\\wireguard.exe',
  ];
  for (const p of paths) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// Download and install WireGuard silently
function downloadAndInstallWireGuard() {
  return new Promise((resolve, reject) => {
    const installerPath = path.join(app.getPath('temp'), 'wireguard-installer.msi');
    const url = 'https://download.wireguard.com/windows-client/wireguard-installer.exe';
    
    const file = fs.createWriteStream(installerPath);
    https.get(url, (response) => {
      if (response.statusCode === 302 || response.statusCode === 301) {
        https.get(response.headers.location, (res) => {
          res.pipe(file);
          file.on('finish', () => {
            file.close();
            try {
              execSync(`"${installerPath}" /S`, { timeout: 120000 });
              resolve(true);
            } catch (e) {
              reject(new Error('Falha ao instalar WireGuard: ' + e.message));
            }
          });
        });
      } else {
        response.pipe(file);
        file.on('finish', () => {
          file.close();
          try {
            execSync(`"${installerPath}" /S`, { timeout: 120000 });
            resolve(true);
          } catch (e) {
            reject(new Error('Falha ao instalar WireGuard: ' + e.message));
          }
        });
      }
    }).on('error', reject);
  });
}

// IPC Handlers
ipcMain.handle('login', async (_, email, password) => {
  try {
    const result = await supabaseLogin(email, password);
    if (result.access_token) {
      authToken = result.access_token;
      return { success: true, user: result.user };
    }
    return { success: false, error: result.error_description || result.msg || 'Erro no login' };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('check-wireguard', async () => {
  return { installed: isWireGuardInstalled() };
});

ipcMain.handle('install-wireguard', async () => {
  try {
    await downloadAndInstallWireGuard();
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('activate-key', async (_, key) => {
  try {
    const result = await supabaseFetch('vpn-manage', { action: 'activate', activation_key: key }, authToken);
    return result;
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('get-vpn-status', async () => {
  try {
    return await supabaseFetch('vpn-manage', { action: 'status' }, authToken);
  } catch (e) {
    return { active: false };
  }
});

ipcMain.handle('connect-vpn', async () => {
  try {
    // Get config from server
    const configResult = await supabaseFetch('vpn-manage', { action: 'get-config' }, authToken);
    if (!configResult.success) return { success: false, error: configResult.error };

    // Write config file
    const configDir = path.join(app.getPath('appData'), 'SnyX-VPN');
    if (!fs.existsSync(configDir)) fs.mkdirSync(configDir, { recursive: true });
    const configPath = path.join(configDir, 'snyx-vpn.conf');
    fs.writeFileSync(configPath, configResult.config);

    // Install tunnel service
    const wgPath = getWireGuardPath();
    if (!wgPath) return { success: false, error: 'WireGuard não encontrado' };

    try {
      execSync(`"${wgPath}" /installtunnelservice "${configPath}"`, { timeout: 30000 });
    } catch (e) {
      // May need admin rights
      return { success: false, error: 'Execute como administrador para conectar a VPN' };
    }

    return { success: true, ip: configResult.assigned_ip, server: configResult.server_ip };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('disconnect-vpn', async () => {
  try {
    const wgPath = getWireGuardPath();
    if (wgPath) {
      execSync(`"${wgPath}" /uninstalltunnelservice snyx-vpn`, { timeout: 15000 });
    }
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('minimize-window', () => { mainWindow?.minimize(); });
ipcMain.handle('close-window', () => { app.quit(); });
ipcMain.handle('open-external', (_, url) => { shell.openExternal(url); });
