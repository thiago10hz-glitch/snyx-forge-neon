@echo off
title SnyX VPN - Construindo...
color 0C
echo.
echo  ============================================
echo        SnyX VPN - Instalador Automatico
echo  ============================================
echo.
echo  [1/3] Instalando dependencias...
call npm install
echo.
echo  [2/3] Instalando Electron...
call npm install --save-dev electron @electron/packager
echo.
echo  [3/3] Gerando SnyX-VPN.exe para Windows...
call npx @electron/packager . "SnyX-VPN" --platform=win32 --arch=x64 --out=release --overwrite
echo.
echo  ============================================
echo        PRONTO! Seu .exe esta em:
echo        release\SnyX-VPN-win32-x64\
echo  ============================================
echo.
pause
