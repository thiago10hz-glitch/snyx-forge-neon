const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("snyx", {
  // Window
  minimize: () => ipcRenderer.invoke("window-minimize"),
  maximize: () => ipcRenderer.invoke("window-maximize"),
  close: () => ipcRenderer.invoke("window-close"),
  quit: () => ipcRenderer.invoke("window-quit"),
  
  // System
  getSystemInfo: () => ipcRenderer.invoke("get-system-info"),
  
  // License
  activateLicense: (key) => ipcRenderer.invoke("activate-license", key),
  checkLicense: () => ipcRenderer.invoke("check-license"),
  deactivateLicense: () => ipcRenderer.invoke("deactivate-license"),
  
  // Connection
  connect: () => ipcRenderer.invoke("connect"),
  disconnect: () => ipcRenderer.invoke("disconnect"),
  getStatus: () => ipcRenderer.invoke("get-status"),
  
  // Tools
  speedTest: () => ipcRenderer.invoke("speed-test"),
  openSite: () => ipcRenderer.invoke("open-site"),
  
  // Events
  onLicenseExpired: (cb) => ipcRenderer.on("license-expired", cb),
  onLicenseStatus: (cb) => ipcRenderer.on("license-status", (_, data) => cb(data)),
});
