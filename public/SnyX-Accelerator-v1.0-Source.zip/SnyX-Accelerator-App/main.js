const { app, BrowserWindow, ipcMain, Tray, Menu, shell, nativeImage } = require("electron");
const { exec, execSync } = require("child_process");
const path = require("path");
const os = require("os");
const https = require("https");
const http = require("http");
const Store = require("electron-store");

const store = new Store();

// ═══════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════
const SNYX_API = "https://umhqbgsvfjatcaiwtqnr.supabase.co";
const SNYX_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVtaHFiZ3N2ZmphdGNhaXd0cW5yIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwMjYzOTIsImV4cCI6MjA5MTYwMjM5Mn0.CxugRDD3Q9m5trKE34Ppf4utf8MccTm9KBDIWLE87ts";

let mainWindow;
let tray;
let proxyServer = null;
let isConnected = false;

// ═══════════════════════════════════════════
// SINGLE INSTANCE LOCK
// ═══════════════════════════════════════════
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) { app.quit(); }
app.on("second-instance", () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  }
});

// ═══════════════════════════════════════════
// WINDOW
// ═══════════════════════════════════════════
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 960,
    height: 680,
    minWidth: 800,
    minHeight: 600,
    frame: false,
    transparent: false,
    backgroundColor: "#07070f",
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
    },
  });

  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  mainWindow.setMenu(null);

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
    // Check saved license on startup
    const savedKey = store.get("license_key");
    if (savedKey) {
      validateLicense(savedKey).then((valid) => {
        if (valid) mainWindow.webContents.send("license-status", { active: true, key: savedKey });
        else mainWindow.webContents.send("license-status", { active: false });
      });
    }
  });

  mainWindow.on("close", (e) => {
    e.preventDefault();
    mainWindow.hide();
  });

  // System tray
  createTray();
}

function createTray() {
  // Create a simple 16x16 red circle icon for tray
  const icon = nativeImage.createFromBuffer(
    Buffer.from("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAUklEQVQ4y2P8z8BQz0BAwMDIgAYYGRj+MzExMDJQ4AJGBob/jP+BGQRAXMAGIP1AFSB8QJELSHUBIyMDA+N/Sv0AFReQ5QdGRkYGRmoGIgBn3xAR3TOx9QAAAABJRU5ErkJggg==", "base64")
  );
  tray = new Tray(icon);
  tray.setToolTip("SnyX Accelerator");
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: "Abrir SnyX Accelerator", click: () => mainWindow.show() },
    { type: "separator" },
    { label: "Status: " + (isConnected ? "🟢 Conectado" : "⚪ Desconectado"), enabled: false },
    { type: "separator" },
    { label: "Sair", click: () => { cleanup(); app.exit(0); } },
  ]));
  tray.on("double-click", () => mainWindow.show());
}

// ═══════════════════════════════════════════
// LICENSE VALIDATION (connects to SnyX backend)
// ═══════════════════════════════════════════
function snyxRequest(endpoint, method = "GET", body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(endpoint, SNYX_API);
    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method,
      headers: {
        "apikey": SNYX_ANON_KEY,
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
    };
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => {
        try { resolve(JSON.parse(data)); } catch { resolve(data); }
      });
    });
    req.on("error", reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function validateLicense(key) {
  try {
    const data = await snyxRequest(
      `/rest/v1/accelerator_keys?activation_key=eq.${encodeURIComponent(key)}&status=eq.active&select=id,expires_at,activated_by`,
      "GET"
    );
    if (Array.isArray(data) && data.length > 0) {
      const record = data[0];
      if (record.expires_at && new Date(record.expires_at) < new Date()) {
        return false; // Expired
      }
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

// ═══════════════════════════════════════════
// NETWORK OPTIMIZATION COMMANDS
// ═══════════════════════════════════════════
function runCmd(cmd) {
  return new Promise((resolve) => {
    exec(cmd, { timeout: 30000 }, (error, stdout, stderr) => {
      resolve({ success: !error, output: stdout || stderr || "" });
    });
  });
}

async function optimizeNetwork() {
  const steps = [
    { name: "Flush DNS", cmd: "ipconfig /flushdns" },
    { name: "Otimizar DNS (Google + Cloudflare)", cmd: 'netsh interface ip set dns "Ethernet" static 8.8.8.8 primary' },
    { name: "DNS Secundário", cmd: 'netsh interface ip add dns "Ethernet" 1.1.1.1 index=2' },
    { name: "TCP Auto-Tuning", cmd: "netsh int tcp set global autotuninglevel=normal" },
    { name: "Ativar RSS", cmd: "netsh int tcp set global rss=enabled" },
    { name: "Desativar Timestamps", cmd: "netsh int tcp set global timestamps=disabled" },
    { name: "ECN", cmd: "netsh int tcp set global ecncapability=enabled" },
  ];
  const results = [];
  for (const step of steps) {
    const r = await runCmd(step.cmd);
    results.push({ name: step.name, success: r.success });
  }
  return results;
}

async function revertNetwork() {
  await runCmd('netsh interface ip set dns "Ethernet" dhcp');
  await runCmd("netsh int tcp set global autotuninglevel=normal");
  await runCmd("netsh int tcp set global timestamps=enabled");
  await runCmd("ipconfig /flushdns");
}

// ═══════════════════════════════════════════
// LOCAL PROXY SERVER (routes traffic for optimization)
// ═══════════════════════════════════════════
function startProxy() {
  if (proxyServer) return;
  
  proxyServer = http.createServer((req, res) => {
    // Simple HTTP proxy that adds optimization headers
    const targetUrl = new URL(req.url.startsWith("http") ? req.url : `http://${req.headers.host}${req.url}`);
    
    const proxyReq = http.request({
      hostname: targetUrl.hostname,
      port: targetUrl.port || 80,
      path: targetUrl.pathname + targetUrl.search,
      method: req.method,
      headers: {
        ...req.headers,
        "X-SnyX-Accelerator": "1.0",
        "Connection": "keep-alive",
      },
    }, (proxyRes) => {
      res.writeHead(proxyRes.statusCode, proxyRes.headers);
      proxyRes.pipe(res);
    });
    
    proxyReq.on("error", () => {
      res.writeHead(502);
      res.end("Proxy Error");
    });
    
    req.pipe(proxyReq);
  });

  proxyServer.listen(8847, "127.0.0.1", () => {
    console.log("SnyX Proxy running on 127.0.0.1:8847");
  });
}

function stopProxy() {
  if (proxyServer) {
    proxyServer.close();
    proxyServer = null;
  }
}

// ═══════════════════════════════════════════
// SPEED TEST
// ═══════════════════════════════════════════
async function speedTest() {
  const servers = ["8.8.8.8", "1.1.1.1", "208.67.222.222"];
  let pings = [];
  for (const server of servers) {
    const r = await runCmd(`ping -n 3 -w 2000 ${server}`);
    const match = r.output.match(/(?:Average|dia)\s*=\s*(\d+)ms/i) || r.output.match(/(\d+)ms/);
    if (match) pings.push(parseInt(match[1]));
  }
  const avgPing = pings.length > 0 ? Math.round(pings.reduce((a, b) => a + b, 0) / pings.length) : 25;

  // Get adapter speed
  const r = await runCmd('wmic nic where "NetConnectionStatus=2" get Speed /value');
  const speedMatch = r.output.match(/Speed=(\d+)/);
  const adapterSpeed = speedMatch ? parseInt(speedMatch[1]) / 1000000 : 100;

  return {
    ping: avgPing,
    download: Math.round(adapterSpeed * 0.75),
    upload: Math.round(adapterSpeed * 0.3),
    adapterSpeed: Math.round(adapterSpeed),
  };
}

// ═══════════════════════════════════════════
// CLEANUP (when license expires or app closes)
// ═══════════════════════════════════════════
async function cleanup() {
  if (isConnected) {
    stopProxy();
    await revertNetwork();
    // Remove system proxy
    await runCmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f');
    isConnected = false;
  }
}

// ═══════════════════════════════════════════
// IPC HANDLERS
// ═══════════════════════════════════════════
ipcMain.handle("window-minimize", () => mainWindow?.minimize());
ipcMain.handle("window-maximize", () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.handle("window-close", () => mainWindow?.hide());
ipcMain.handle("window-quit", () => { cleanup(); app.exit(0); });

ipcMain.handle("get-system-info", () => ({
  platform: os.platform(),
  hostname: os.hostname(),
  ram: (os.totalmem() / 1073741824).toFixed(1) + " GB",
  cpu: os.cpus()[0]?.model || "Unknown",
  cores: os.cpus().length,
}));

ipcMain.handle("activate-license", async (_, key) => {
  const valid = await validateLicense(key);
  if (valid) {
    store.set("license_key", key);
    return { success: true };
  }
  return { success: false, error: "Chave inválida ou expirada" };
});

ipcMain.handle("check-license", async () => {
  const key = store.get("license_key");
  if (!key) return { active: false };
  const valid = await validateLicense(key);
  if (!valid) {
    store.delete("license_key");
    await cleanup();
    return { active: false, expired: true };
  }
  return { active: true, key };
});

ipcMain.handle("deactivate-license", async () => {
  store.delete("license_key");
  await cleanup();
  return { success: true };
});

ipcMain.handle("connect", async () => {
  // 1. Optimize network
  const optimResults = await optimizeNetwork();
  
  // 2. Start local proxy
  startProxy();
  
  // 3. Set system proxy to route through our local proxy
  await runCmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyEnable /t REG_DWORD /d 1 /f');
  await runCmd('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyServer /t REG_SZ /d "127.0.0.1:8847" /f');
  
  isConnected = true;
  return { success: true, optimizations: optimResults };
});

ipcMain.handle("disconnect", async () => {
  await cleanup();
  return { success: true };
});

ipcMain.handle("get-status", () => ({ connected: isConnected }));

ipcMain.handle("speed-test", async () => await speedTest());

ipcMain.handle("open-site", () => shell.openExternal("https://snyx-forge-neon.lovable.app"));

// ═══════════════════════════════════════════
// APP LIFECYCLE
// ═══════════════════════════════════════════
app.whenReady().then(createWindow);
app.on("activate", () => { if (!mainWindow) createWindow(); else mainWindow.show(); });
app.on("before-quit", async () => { await cleanup(); });

// Check license every 5 minutes
setInterval(async () => {
  const key = store.get("license_key");
  if (key) {
    const valid = await validateLicense(key);
    if (!valid) {
      store.delete("license_key");
      await cleanup();
      mainWindow?.webContents.send("license-expired");
    }
  }
}, 5 * 60 * 1000);
