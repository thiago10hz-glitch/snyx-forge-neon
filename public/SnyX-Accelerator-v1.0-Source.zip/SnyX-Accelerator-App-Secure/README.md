# SnyX Accelerator - App Desktop

## Como Construir o .exe (Instalador)

### Pré-requisito
- **Node.js** instalado → [https://nodejs.org](https://nodejs.org) (versão LTS)

### Passo a Passo

1. **Extraia** esta pasta no seu PC
2. **Clique duas vezes** em `CONSTRUIR.bat`
3. **Aguarde** — vai instalar tudo e gerar o .exe
4. O instalador estará em `release/SnyX Accelerator Setup 1.0.0.exe`

### O que o instalador faz
- Instala o app com **um clique** (sem perguntas)
- Cria atalho na **Área de Trabalho**
- Cria atalho no **Menu Iniciar**
- Tem **desinstalador** automático

### Funcionalidades do App
- 🔑 **Ativação por chave** — conecta ao backend SnyX
- ⚡ **Conexão à Rede SnyX** — otimiza DNS, TCP, proxy local
- 📡 **Teste de velocidade** — ping, download, upload
- 🛡️ **Proteção automática** — quando a chave expira, tudo volta ao normal
- 🔄 **Verifica licença** a cada 5 minutos automaticamente
- 📋 **Log de atividades** — tudo registrado

### Ícone do App
Coloque um arquivo `icon.ico` na pasta `assets/` para personalizar o ícone.
Tamanho recomendado: 256x256 pixels, formato .ico

### Para Testar sem Construir
```
npm install
npm start
```

### Estrutura
```
SnyX-Accelerator-App/
├── main.js           ← Processo principal (Electron)
├── preload.js        ← Bridge segura (IPC)
├── renderer/
│   └── index.html    ← Interface do app
├── assets/           ← Ícones (coloque icon.ico aqui)
├── package.json      ← Configuração e build
├── CONSTRUIR.bat     ← Script de build (Windows)
└── README.md         ← Este arquivo
```
