@echo off
title SnyX Accelerator - Instalador Automatico v1.0
color 0C
echo.
echo  ============================================================
echo  ⚡ SnyX Accelerator - Instalador Automatico v1.0
echo  ============================================================
echo.

:: Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  [!] Node.js nao encontrado. Baixando automaticamente...
    echo.
    
    :: Download Node.js LTS installer
    echo  [1/5] Baixando Node.js v20 LTS...
    powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.18.1/node-v20.18.1-x64.msi' -OutFile '%TEMP%\nodejs_installer.msi'}"
    
    if not exist "%TEMP%\nodejs_installer.msi" (
        echo  [ERRO] Falha ao baixar Node.js. Verifique sua internet.
        pause
        exit /b 1
    )
    
    echo  [2/5] Instalando Node.js silenciosamente...
    msiexec /i "%TEMP%\nodejs_installer.msi" /qn /norestart
    
    :: Refresh PATH
    set "PATH=%ProgramFiles%\nodejs;%PATH%"
    
    :: Wait for installation
    timeout /t 5 /nobreak >nul
    
    :: Verify installation
    where node >nul 2>nul
    if %errorlevel% neq 0 (
        echo  [ERRO] Instalacao do Node.js falhou. Instale manualmente: https://nodejs.org
        pause
        exit /b 1
    )
    echo  [OK] Node.js instalado com sucesso!
) else (
    echo  [OK] Node.js encontrado!
)

echo.
echo  [3/5] Instalando dependencias do SnyX Accelerator...
cd /d "%~dp0"
call npm install --production 2>nul
if %errorlevel% neq 0 (
    call npm install 2>nul
)
echo  [OK] Dependencias instaladas!

echo.
echo  [4/5] Compilando SnyX Accelerator (.exe)...
call npx electron-builder --win --x64 -c.win.target=nsis 2>nul
if %errorlevel% neq 0 (
    echo  [!] electron-builder falhou, tentando com @electron/packager...
    call npx @electron/packager . "SnyX Accelerator" --platform=win32 --arch=x64 --out=dist --overwrite --icon=assets/icon.ico 2>nul
)
echo  [OK] Compilacao concluida!

echo.
echo  [5/5] Criando atalho na Area de Trabalho...

:: Find the compiled .exe
set "EXE_PATH="
if exist "dist\SnyX Accelerator-win32-x64\SnyX Accelerator.exe" (
    set "EXE_PATH=%~dp0dist\SnyX Accelerator-win32-x64\SnyX Accelerator.exe"
)
if exist "dist\SnyX Accelerator Setup*.exe" (
    for %%f in ("dist\SnyX Accelerator Setup*.exe") do set "EXE_PATH=%%~ff"
)
if exist "dist\win-unpacked\SnyX Accelerator.exe" (
    set "EXE_PATH=%~dp0dist\win-unpacked\SnyX Accelerator.exe"
)

if defined EXE_PATH (
    :: Create desktop shortcut using PowerShell
    powershell -Command "& {$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\SnyX Accelerator.lnk'); $s.TargetPath = '%EXE_PATH%'; $s.WorkingDirectory = '%~dp0'; $s.Description = 'SnyX Accelerator - Otimizacao de Rede'; $s.Save()}"
    echo  [OK] Atalho criado na Area de Trabalho!
    
    :: Also create Start Menu shortcut
    powershell -Command "& {$ws = New-Object -ComObject WScript.Shell; $startMenu = [Environment]::GetFolderPath('StartMenu') + '\Programs'; if(!(Test-Path $startMenu)){New-Item -ItemType Directory -Path $startMenu -Force}; $s = $ws.CreateShortcut($startMenu + '\SnyX Accelerator.lnk'); $s.TargetPath = '%EXE_PATH%'; $s.WorkingDirectory = '%~dp0'; $s.Description = 'SnyX Accelerator'; $s.Save()}"
    echo  [OK] Atalho criado no Menu Iniciar!
) else (
    echo  [!] Executavel nao encontrado. Tente executar manualmente:
    echo      npx electron .
)

echo.
echo  ============================================================
echo  ⚡ SnyX Accelerator INSTALADO COM SUCESSO!
echo  ============================================================
echo.
echo  O atalho foi criado na sua Area de Trabalho.
echo  Clique no icone "SnyX Accelerator" para abrir!
echo.
echo  Esta janela vai fechar em 10 segundos...
timeout /t 10
