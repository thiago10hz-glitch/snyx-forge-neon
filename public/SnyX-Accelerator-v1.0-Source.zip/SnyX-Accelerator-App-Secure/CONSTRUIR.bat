@echo off
title SnyX Accelerator - Construtor
color 0C
echo.
echo  ============================================
echo    SnyX Accelerator - Construtor de App
echo  ============================================
echo.
echo  [1/4] Verificando Node.js...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Node.js nao encontrado!
    echo  [!] Baixe em: https://nodejs.org
    echo  [!] Instale e rode este script novamente.
    pause
    start https://nodejs.org
    exit
)
echo  [OK] Node.js encontrado: 
node --version
echo.

echo  [2/4] Instalando dependencias...
call npm install
if %errorlevel% neq 0 (
    echo  [!] Erro ao instalar dependencias!
    pause
    exit
)
echo  [OK] Dependencias instaladas!
echo.

echo  [3/4] Construindo o instalador .exe...
call npm run build
if %errorlevel% neq 0 (
    echo  [!] Erro ao construir!
    echo  [!] Tentando modo portable...
    call npm run build-portable
)
echo.

echo  [4/4] Pronto!
echo.
echo  ============================================
echo    O instalador esta na pasta "release"
echo    Envie o arquivo .exe para seus usuarios!
echo  ============================================
echo.
echo  O instalador cria:
echo    - Atalho na Area de Trabalho
echo    - Atalho no Menu Iniciar
echo    - Desinstalador automatico
echo.
pause
